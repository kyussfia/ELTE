﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AuctionSite.Data
{
    public class Image : Object
    {
        public Byte[] Data { get; set; }
    }
}
